#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

extern int rusty_main();

int input_v = 20;
char *S0 = "%d";
char *S1 = "%d ";

/*
 * rusty_input: read one integer from standard input.
 *
 * If stdin is a redirected file / pipe (i.e. not a terminal) we read
 * integers from it with scanf.  If stdin is a terminal or no more
 * integers are available we fall back to a pseudo-random value in
 * [0, input_v) so programs still run interactively exactly like the
 * original driver.
 */
int rusty_input() {
	int d = 0;
	if (!isatty(fileno(stdin))) {
		if (scanf("%d", &d) == 1) return d;
	}
	return rand() % input_v;
}

int
main(int argc, char **argv) {
	time_t t;
	srand((unsigned) time(&t));
	if (argc > 1) input_v = atoi(argv[1]);
	if (input_v <= 0) input_v = 20;
	rusty_main();
	return 0;
}
